Team Members: Ngawang Kyirong - 301312227 and Jing Wen - 301327176

Acknowledgements: Used the pseudo-code given to us in the assignment guidelines, referenced various documentation on in built C functions such as:
clock_gettime()

Running the shell: enter "make", enter "./candykids 2 2 10"

Makefile: the Makefile is untouched and directly taken from the assignment page.